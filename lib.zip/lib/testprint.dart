import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:intl/intl.dart';

class TestPrint {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  sample(String companyName,String type,String itemName,String sellingCost,String mrp,String qty,String totalCost,String employeeId,String code,String brand,String qtyType) async {
    final DateFormat formatter = DateFormat('dd-MM-yyyy');
    final String formatted =
    formatter.format(DateTime.now());
    String time=new DateFormat.jm().format(DateTime.now());
    //SIZE
    // 0- normal size text
    // 1- only bold text
    // 2- bold with medium text
    // 3- bold with large text
    //ALIGN
    // 0- ESC_ALIGN_LEFT
    // 1- ESC_ALIGN_CENTER
    // 2- ESC_ALIGN_RIGHT

//     var response = await http.get("IMAGE_URL");
//     Uint8List bytes = response.bodyBytes;
    bluetooth.isConnected.then((isConnected) {
      if (isConnected) {

        bluetooth.printCustom(companyName, 2, 1);
        bluetooth.printQRcode(code, 200, 75, 1);
        bluetooth.printCustom(itemName,1, 0);
        bluetooth.printCustom("Price : "+sellingCost+"  MRP: "+mrp,1, 0);
        bluetooth.printCustom("Qty: "+qty+"  Brand "+brand, 1, 0);
        bluetooth.printCustom("Net Amount: "+totalCost+"Type "+qtyType, 1, 0);
        bluetooth.printCustom("Date: "+formatted+" "+time+" "+"   Emp Id:"+employeeId,0, 0);
        bluetooth.printCustom("Powered By Hisan Technologies",0, 0);
        bluetooth.printCustom("www.hisantechnologies.com",0, 0);

         bluetooth.printNewLine();
         bluetooth.printNewLine();
        //bluetooth.paperCut();

      // else
      //   {
      //     bluetooth.printCustom("LULU HYPER", 2, 1);
      //     bluetooth.printQRcode(code, 200, 100, 1);
      //     bluetooth.printCustom(itemName,1, 0);
      //     bluetooth.printCustom("Price : "+sellingCost+"  MRP: "+mrp,1, 0);
      //     bluetooth.printCustom("Qty: "+qty, 1, 0);
      //     bluetooth.printCustom("Net Amount: "+totalCost, 1, 0);
      //     bluetooth.printCustom("Date: "+formatted,0, 0);
      //     bluetooth.printCustom("Powered By Hisan Technology",0, 0);bluetooth.printNewLine();
      //     bluetooth.printNewLine();
      //
      //   }
      }
    });
  }
}
