import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_app_check/startPage.dart';


void main() => runApp(StartPage());


