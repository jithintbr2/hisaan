import 'package:flutter/material.dart';
import 'package:flutter_app_check/spalshScreen.dart';



class StartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: Splash2());
  }


}
