//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_app_check/common.dart';
// import 'package:flutter_app_check/dashboard.dart';
// import 'package:flutter_app_check/httpService.dart';
// import 'package:flutter_app_check/loginModel.dart';
//
//
//
// class Login extends StatefulWidget {
//   String serialNo;
//   Login(this.serialNo);
//   @override
//   _LoginState createState() => _LoginState();
// }
//
// class _LoginState extends State<Login> {
//   TextEditingController username = new TextEditingController();
//   TextEditingController password = new TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//
//
//
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: Container(
//           width: double.infinity,
//           height: size.height,
//           decoration: new BoxDecoration(
//
//               gradient: new LinearGradient(
//                 begin: Alignment.topCenter,
//                   end: Alignment.bottomCenter,
//                   colors: [
//                     Color.fromRGBO(115,197,237,1),
//                     Color.fromRGBO(58,177,158,1)
//                   ]
//               )
//           ),
//
//
//           child: Stack(
//
//             alignment: Alignment.center,
//             children: <Widget>[
//
//
//               Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   CircleAvatar(
//                     backgroundImage:AssetImage('assets/images/logo.png'),
//                     radius: 70,
//                   ),
//                   SizedBox(height: size.height * 0.03),
//                   Container(
//                     alignment: Alignment.centerLeft,
//                     padding: EdgeInsets.symmetric(horizontal: 20),
//                     child: Text(
//                       "Login",
//                       style: TextStyle(
//                           fontWeight: FontWeight.bold,
//                           color: Colors.white,
//                           fontSize: 25
//                       ),
//                       textAlign: TextAlign.left,
//                     ),
//                   ),
//
//
//
//                   Padding(
//                     padding: const EdgeInsets.only(
//                         left: 20, right: 20, bottom: 10, top: 10),
//                     child: Container(
//                       height: MediaQuery.of(context).size.height * 0.06,
//                       width: MediaQuery.of(context).size.width * 1,
//                       decoration: BoxDecoration(
//                         border: Border.all(color: Colors.white),
//
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       child: Center(
//                         child: TextField(
//                           controller: username,
//                           style: TextStyle(color: Colors.white,fontSize: 20.0),
//                           keyboardType:TextInputType.text,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             prefixIcon: Icon(Icons.person,color: Colors.white,),
//                             hintText: 'Username',
//                             hintStyle: TextStyle(fontSize: 20.0, color: Colors.white),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//
//
//                   SizedBox(height: size.height * 0.01),
//
//                   Padding(
//                     padding: const EdgeInsets.only(
//                         left: 20, right: 20, bottom: 10),
//                     child: Container(
//                       height: MediaQuery.of(context).size.height * 0.06,
//                       width: MediaQuery.of(context).size.width * 1,
//                       decoration: BoxDecoration(
//                         border: Border.all(color: Colors.white),
//
//                         borderRadius: BorderRadius.circular(25),
//                       ),
//                       child: Center(
//                         child: TextField(
//                           style: TextStyle(color: Colors.white,fontSize: 20.0),
//                           controller: password,
//                           obscureText: true,
//                           decoration: InputDecoration(
//                             border: InputBorder.none,
//                             prefixIcon: Icon(Icons.lock,color: Colors.white,),
//                             hintText: 'Password',
//                             hintStyle: TextStyle(fontSize: 20.0, color: Colors.white),
//
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   SelectableText('Serial Number: '+widget.serialNo,style:TextStyle(fontSize: 18),),
//
//                   // Container(
//                   //   alignment: Alignment.centerRight,
//                   //   margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
//                   //   child: Text(
//                   //     "Forgot your password?",
//                   //     style: TextStyle(
//                   //         fontSize: 15,
//                   //         color: Colors.white
//                   //     ),
//                   //   ),
//                   // ),
//
//                   SizedBox(height: size.height * 0.01),
//
//                   Container(
//                     alignment: Alignment.center,
//                     margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
//                     child: RaisedButton(
//                       onPressed: () async {
//                         if (username.text.isEmpty) {
//                           Common.toastMessaage(
//                               'Username cannot be empty', Colors.red);
//                         } else if (password.text.isEmpty) {
//                           Common.toastMessaage(
//                               'Password cannot be empty', Colors.red);
//                         }
//                         else {
//                           Common.showProgressDialog(context, "Loading..");
//
//
//                           LoginModel object = await HttpService.login(
//                               username.text, password.text,widget.serialNo);
//
//                           if (object.status == true) {
//
//                             Common.saveSharedPref("tocken",object.data.token);
//                             Common.saveSharedPref("companyName",object.data.companyName);
//                             Common.saveSharedPref("fileName",object.data.fileName);
//                             Common.saveSharedPref("barcodePosition",object.data.position.barCode.toString());
//                             Common.saveSharedPref("itemNamePosition",object.data.position.itemName.toString());
//                             Common.saveSharedPref("brandPosition",object.data.position.brand.toString());
//                             Common.saveSharedPref("stockPosition",object.data.position.stock.toString());
//                             Common.saveSharedPref("salesPricePosition",object.data.position.salesPrice.toString());
//                             Common.saveSharedPref("mrpPosition",object.data.position.mrp.toString());
//                             Navigator.of(context).pushAndRemoveUntil(
//                                 MaterialPageRoute(
//                                     builder: (context) =>
//                                         Dashboard(object.data.token,false,'Barcode',widget.serialNo)),
//                                     (Route<dynamic> route) => false);
//
//
//                             Common.toastMessaage(
//                                 'Login Success Please Wait', Colors.green);
//                           } else {
//                             Navigator.pop(context);
//                             Common.toastMessaage(
//                                 object.message, Colors.red);
//                           }
//
//
//                         }
//
//
//
//                       },
//                       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80.0)),
//                       textColor: Colors.white,
//                       padding: const EdgeInsets.all(0),
//                       child: Container(
//                         alignment: Alignment.center,
//                         height: 50.0,
//                         width: size.width * 0.5,
//                         decoration: new BoxDecoration(
//                             borderRadius: BorderRadius.circular(80.0),
//                             color: Colors.white
//                         ),
//                         padding: const EdgeInsets.all(0),
//                         child: Text(
//                           "LOGIN",
//                           textAlign: TextAlign.center,
//                           style: TextStyle(
//                               fontWeight: FontWeight.bold,color: Colors.black
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: size.height * 0.1),
//                   Container(
//                     alignment: Alignment.center,
//                     margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
//                     child:Column(
//                       children: [
//                         Text('Powered by',textAlign: TextAlign.center,
//                           style: TextStyle(
//                               color: Colors.white,
//                             fontSize: 15,
//                           ),),
//                     Container(
//                       height: 40,
//                       width: 130,
//                       child: Image.asset(
//                         "assets/images/hisanLogo.png",
//                         fit: BoxFit.fill,
//                       ),
//                     ),
//                         // Text('Hisan',textAlign: TextAlign.center,
//                         //   style: TextStyle(
//                         //     color: Colors.white,
//                         //     fontSize: 40,fontWeight: FontWeight.bold
//                         //   ),),
//                         Text('www.hisantechnology.com',textAlign: TextAlign.center,
//                           style: TextStyle(
//                               color: Colors.white,
//                               fontSize: 20
//                           ),)
//                       ],
//                     ),
//                   ),
//
//
//                 ],
//               ),
//           Align(),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }